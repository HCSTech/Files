#!/bin/bash


# Install TeamViewer Silent
/usr/sbin/installer -applyChoiceChangesXML /private/tmp/choices.xml -pkg /private/tmp/TeamViewer_Host.pkg -target /

# Wait for TeamViewer to start
/bin/sleep 60

# Assign TeamViewer
/Applications/TeamViewerHost.app/Contents/Helpers/TeamViewer_Assignment -api-token "$4" -group "$5" -grant-easy-access -reassign

# Restrict Changes to Admin users only
/usr/bin/defaults write /Library/Preferences/com.teamviewer.teamviewer.preferences.plist Security_Adminrights -integer 1
